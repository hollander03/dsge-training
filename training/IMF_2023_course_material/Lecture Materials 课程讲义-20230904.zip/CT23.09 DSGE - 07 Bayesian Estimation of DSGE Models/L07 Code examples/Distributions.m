    
% Examples of beta and gamma distributions holding the mean fixed
% parameters of the Beta distribution
% a - first shape parameter (positive scalar value)
% b - second shape parameter (positive scalar value)

close all; clear all;

rng('default');

% a = [0.2, 0.5, 1, 1.5, 2, 0.5];
% b = [0.0, 0.0, 0.0, 0.0, 0.0, -1.0];
a = [0.3, 0.5, 1,   1.5,    1.0];
b = [0.0, 0.0, 0.0, 0.0,   -2.0];


xx=-10:.1:10;

figure(1)
for i=1:size(a,2); 
    y = normpdf(xx,b(i),a(i));
    %mean(i) = a(i)/(a(i)+b(i));
    %var(i) = a(i)*b(i)/((a(i)+b(i))^2*(a(i)+b(i)+1));
    plot(xx, y,'color',rand(1,3), 'LineWidth', 2); 
    Legend{i}=strcat('Mean =   ',num2str(b(i)),' Var =   ',num2str(a(i)));
    hold on;
    title('Normal distributions         ')
end
legend(Legend)

rng('default');

% a = [1, 2, 3, 5, 10, 20];
% b = 2/3*a; % ensures that the mean is 0.6
a = [0.5, 5, 1, 2, 2  ];
b = [0.5, 1, 3, 2, 5  ]; % ensures that the mean is 0.6
xx=0:.001:1;

figure(2)
for i=1:size(a,2); 
    y = betapdf(xx,a(i),b(i));
     mean(i) = a(i)/(a(i)+b(i));
     var(i) = a(i)*b(i)/((a(i)+b(i))^2*(a(i)+b(i)+1));
    plot(xx, y,'color',rand(1,3), 'LineWidth', 2); 
     axis([0 1 0 3]);
    Legend{i}=strcat('a =  ',num2str(a(i)),', b =  ',num2str(b(i),2));
    hold on;
    % title('Beta distributions holding the mean fixed')
    title('Beta distributions ')
end
legend(Legend)



% Examples of inverse gamma distributions holding the mean fixed

rng('default');

a = [1, 2, 3, 5, 10, 20];
b =0.6*(a-1); % ensures that the mean is 0.6

xx=0:.1:100;
figure(3)
for i=1:size(a,2); 
    y = gampdf(xx,a(i),b(i));
%     mean(i) = a(i)/(a(i)+b(i));
%     var(i) = a(i)*b(i)/((a(i)+b(i))^2*(a(i)+b(i)+1));
    plot(xx, y,'color',rand(1,3), 'LineWidth', 2); 
    Legend{i}=strcat('a =  ',num2str(a(i)),', b =  ',num2str(b(i),2));
    %legend('a =',num2str(a(i)),'b =',num2str(b(i)),'location','Best');
    hold on;
    title('Inverse Gamma distributions holding the mean fixed')
end
legend(Legend)
mean
var


% rng('default');
% 
% a = [1, 2, 3, 5, 10, 20];
% b =0.6*(a-1); % ensures that the mean is 0.6
% 
% xx=0:.1:100;
% figure(4)
% for i=1:size(a,2); 
%     y = 1./gampdf(xx,a(i),b(i));
% %     mean(i) = a(i)/(a(i)+b(i));
% %     var(i) = a(i)*b(i)/((a(i)+b(i))^2*(a(i)+b(i)+1));
%     plot(xx, y,'color',rand(1,3), 'LineWidth', 2); 
%     Legend{i}=strcat('a =  ',num2str(a(i)),', b =  ',num2str(b(i),2));
%     %legend('a =',num2str(a(i)),'b =',num2str(b(i)),'location','Best');
%     hold on;
%     title('Inverse Gamma distributions holding the mean fixed')
% end
% legend(Legend)
% var
% 

