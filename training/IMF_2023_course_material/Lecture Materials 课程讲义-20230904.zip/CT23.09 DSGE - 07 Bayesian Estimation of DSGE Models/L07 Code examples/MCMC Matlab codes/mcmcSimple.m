% This file has a simple example of the monte carlo simulation
% Assume that we want to compute the mean and variance of the normal distribution 
% with mean zero and variance 

close all;
clc;clear all;
fobj = @(theta) exp(-0.5*((theta-1).^2)); % function calculating normal pdf with mean 1 given theta
% in general, fobj computes the posterior value given theta, so it would
% apply Kalman filter and then multiply prior by the likelyhood. Here we
% assume we know the posterior distribution, and we just want to see how
% well will MH algorythm approximate it

%mcmc algorithm
fstmc=0;
Sigma = 1; % variance assumed to be 1
mc = 100000;
burn = 50000;
fstmc = zeros(mc, 2); % 100000x2 matrix of zeros so far. this will contain our final sample of draws
mh_jscale = 6; % scaling parameter for the variance (c in lecture)
Inival = [1,-1];
for  j = 1:2 % Number of monte carlo repetitions
    oldTheta = Inival(j);
    fold = fobj(oldTheta); % when j=1 oldTheta=1, when j=2 oldTheta = -1. Two starting values
    accept = 0;
    for i =1:mc  % Mcmc algorithm
        newTheta = oldTheta + mh_jscale*sqrt(Sigma)*randn();
        fnew = fobj(newTheta); 
        r = fnew/fold;
        if (rand(1,1) < r) % if r>1 than rand(1,1) will always be smaller than r. otherwise the probability of acceptance will depend on r
            oldTheta = newTheta;
            fold = fnew;
            accept = accept + 1;
        end
        fstmc(i, j) = oldTheta;
    end
end

accept/mc

figure()
rep1 = cumsum(fstmc(:,1))./linspace(1,mc,mc)'; % basically current mean theta at every point
rep2 = cumsum(fstmc(:,2))./linspace(1,mc,mc)';
plot([rep1 rep2]);
% a lot of volatility in the beginning, but then stabilized
KeepS=fstmc(burn:end,:);
% cutoff the first part of draws (to remove impreciseness)
[mean(KeepS) ; var(KeepS)]

% so final mean and variance depend on initial values, for theta=-1 they
% are worse, but the difference is not that much

indx = find(KeepS(:, 1)>0);
mean(KeepS(indx, 1))

% draws in the sample are not only those close to the mean. there are many
% negative draws (basically, draws from tails) so the algorithm does parses
% through the whole distribution