function y = US_SW07_rep_set_auxiliary_variables(y, x, params)
%
% Status : Computes static model for Dynare
%
% Warning : this file is generated automatically by Dynare
%           from model file (.mod)

y(43)=y(29);
y(44)=y(29);
