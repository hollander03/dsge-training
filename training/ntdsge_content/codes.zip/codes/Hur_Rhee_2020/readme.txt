Please unzip the zip file.
run MAINSCRIPT_pv_mul_news_equal_surprise.m in the sub directory \Results.additional.rp
You will get Figure 2 in the paper.